from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from trialiq.services.answer_service import (
    answer_trial_overview_by_nct_id,
)
from trialiq.services.models import (
    AnswerStatus,
    EvidenceGroundedAnswer,
)


router = APIRouter(
    prefix="/trials",
    tags=["trials"],
)


class TrialOverviewRequest(BaseModel):
    nct_id: str = Field(
        ...,
        min_length=1,
        description="ClinicalTrials.gov NCT identifier.",
    )


@router.post(
    "/overview",
    response_model=EvidenceGroundedAnswer,
)
def get_trial_overview(
    request: TrialOverviewRequest,
) -> EvidenceGroundedAnswer:
    try:
        result = answer_trial_overview_by_nct_id(
            request.nct_id
        )
    except Exception:
        raise HTTPException(
            status_code=500,
            detail="Internal server error while retrieving trial overview.",
        )

    if result.status == AnswerStatus.EXECUTION_ERROR:
        raise HTTPException(
            status_code=500,
            detail=result.model_dump(),
        )

    return result
