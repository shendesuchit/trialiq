# Change Start
"""Natural-language query orchestration for TrialIQ."""

from trialiq.chains.intent_extraction import extract_query_intent
from trialiq.services.models import (
    OrchestrationResponse,
    OrchestrationStatus,
)
from trialiq.services.query_intent import (
    QueryIntent,
    QueryIntentRequest,
    dispatch_query,
)


def answer_question(question: str) -> OrchestrationResponse:
    if not question or not question.strip():
        return OrchestrationResponse(
            status=OrchestrationStatus.VALIDATION_FAILED,
            message="The question cannot be empty.",
        )

    try:
        extracted_intent = extract_query_intent(question)

        if extracted_intent.intent == QueryIntent.UNSUPPORTED:
            return OrchestrationResponse(
                status=OrchestrationStatus.UNSUPPORTED,
                message=(
                    "The requested question is outside the supported "
                    "query capabilities."
                ),
                intent=extracted_intent.intent.value,
                nct_id=extracted_intent.nct_id,
            )

        if not extracted_intent.nct_id:
            return OrchestrationResponse(
                status=OrchestrationStatus.MISSING_NCT_ID,
                message=(
                    "No NCT ID was found in the question. "
                    "Please provide a specific clinical trial NCT ID."
                ),
                intent=extracted_intent.intent.value,
            )

        query_request = QueryIntentRequest(
            intent=extracted_intent.intent,
            nct_id=extracted_intent.nct_id,
        )

        graph_response = dispatch_query(query_request)

        status_mapping = {
            "SUCCESS": OrchestrationStatus.SUCCESS,
            "NOT_FOUND": OrchestrationStatus.NOT_FOUND,
            "VALIDATION_FAILED": OrchestrationStatus.VALIDATION_FAILED,
            "EXECUTION_ERROR": OrchestrationStatus.EXECUTION_ERROR,
        }

        orchestration_status = status_mapping.get(
            graph_response.status.value,
            OrchestrationStatus.EXECUTION_ERROR,
        )

        message_mapping = {
            OrchestrationStatus.SUCCESS: "The query was processed successfully.",
            OrchestrationStatus.NOT_FOUND: (
                "The requested clinical trial was not found."
            ),
            OrchestrationStatus.VALIDATION_FAILED: (
                "The graph evidence failed validation."
            ),
            OrchestrationStatus.EXECUTION_ERROR: (
                "The graph query encountered an execution error."
            ),
        }

        return OrchestrationResponse(
            status=orchestration_status,
            message=message_mapping[orchestration_status],
            intent=extracted_intent.intent.value,
            nct_id=extracted_intent.nct_id,
            graph_response=graph_response,
        )

    except ValueError as exc:
        return OrchestrationResponse(
            status=OrchestrationStatus.VALIDATION_FAILED,
            message="The supplied query failed validation.",
        )

    except Exception:
        return OrchestrationResponse(
            status=OrchestrationStatus.EXECUTION_ERROR,
            message="An unexpected error occurred while processing the query.",
        )


# Change End
