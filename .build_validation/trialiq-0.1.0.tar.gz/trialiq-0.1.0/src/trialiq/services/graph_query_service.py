
# Change Start
"""Read-only graph query service for TrialIQ."""

from trialiq.chains.cypher_qa import get_trial_graph
from trialiq.services.models import (
    GraphQueryResponse,
    GraphQueryStatus,
    ValidationResult,
)
from trialiq.validation.evidence import validate_trial_evidence


def query_trial_by_nct_id(nct_id: str) -> GraphQueryResponse:
    """Retrieve and validate graph evidence for a clinical trial."""

    try:
        evidence = get_trial_graph(nct_id)

        validation = validate_trial_evidence(
            evidence=evidence,
            requested_nct_id=nct_id,
        )

        validation_result = ValidationResult(**validation)

        if evidence.get("found") is not True:
            status = GraphQueryStatus.NOT_FOUND
        elif not validation_result.valid:
            status = GraphQueryStatus.VALIDATION_FAILED
        else:
            status = GraphQueryStatus.SUCCESS

        return GraphQueryResponse(
            status=status,
            nct_id=nct_id,
            evidence=evidence,
            validation=validation_result,
        )

    except Exception as exc:
        return GraphQueryResponse(
            status=GraphQueryStatus.EXECUTION_ERROR,
            nct_id=nct_id,
            evidence=None,
            validation=ValidationResult(
                valid=False,
                errors=[f"Graph query execution failed: {exc}"],
                warnings=[],
            ),
        )


# Change End