
# Change Start
"""Controlled query intent contract for TrialIQ."""

from enum import Enum

from pydantic import BaseModel, ConfigDict, field_validator

from trialiq.services.models import GraphQueryResponse

class QueryIntent(str, Enum):
    TRIAL_OVERVIEW = "TRIAL_OVERVIEW"
    UNSUPPORTED = "UNSUPPORTED"

class QueryIntentRequest(BaseModel):
    """Validated request for a supported graph query intent."""

    model_config = ConfigDict(extra="forbid")

    intent: QueryIntent
    nct_id: str

    @field_validator("nct_id")
    @classmethod
    def validate_nct_id(cls, value: str) -> str:
        normalized = value.strip().upper()

        if not normalized:
            raise ValueError("NCT ID cannot be empty.")

        if not normalized.startswith("NCT"):
            raise ValueError("NCT ID must start with 'NCT'.")

        if not normalized[3:].isdigit():
            raise ValueError("NCT ID must contain digits after 'NCT'.")

        return normalized



# Change Start
def dispatch_query(request: QueryIntentRequest) -> GraphQueryResponse:
    """Route a validated intent to its approved query service."""

    from trialiq.services.graph_query_service import (
        query_trial_by_nct_id,
    )

    if request.intent == QueryIntent.TRIAL_OVERVIEW:
        return query_trial_by_nct_id(request.nct_id)

    if request.intent == QueryIntent.UNSUPPORTED:
        raise ValueError(
            "The requested question is outside the supported query capabilities."
        )

    raise ValueError(f"Unsupported query intent: {request.intent}")
# Change End
 