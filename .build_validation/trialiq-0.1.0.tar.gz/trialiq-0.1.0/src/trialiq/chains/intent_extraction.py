
# Change Start
"""LLM-based structured intent extraction for TrialIQ."""

from pydantic import BaseModel, ConfigDict, Field

from trialiq.llm.factory import create_llm
from trialiq.services.query_intent import QueryIntent
from typing import Optional



class ExtractedQueryIntent(BaseModel):
    """Structured output expected from the LLM."""

    model_config = ConfigDict(extra="forbid")

    intent: QueryIntent = Field(
        description="The supported query intent."
    )
    nct_id: Optional[str] = Field(
        default=None,
        description=(
            "The clinical trial identifier, such as NCT00000105. "
            "Return null when no NCT identifier is present."
        ),
    )


SYSTEM_PROMPT = """You are a clinical trial metadata query-intent extractor.

Your task is to extract the supported query intent and NCT ID
from the user's question.

Supported intents:
- TRIAL_OVERVIEW: Requests an overview of a specific clinical trial.
- UNSUPPORTED: Requests information outside the supported trial overview capability.

Rules:
1. Extract the NCT identifier exactly when present.
2. Return null for nct_id when no NCT identifier is present.
3. Never return placeholder values such as NOT_FOUND, UNKNOWN, or NONE.
4. Use TRIAL_OVERVIEW only when the user requests an overview of a specific trial.
5. Use UNSUPPORTED for comparisons, efficacy assessments, cross-trial analysis, or other unsupported requests.
6. Do not generate Cypher.
7. Do not answer the user's clinical question.
8. Do not infer an NCT ID that is not present.
9. If the user requests a trial overview but does not provide an NCT ID, return TRIAL_OVERVIEW with nct_id=null. Do not classify the request as UNSUPPORTED merely because the NCT ID is missing.
"""


def extract_query_intent(
    question: str,
) -> ExtractedQueryIntent:
    """Extract a validated structured intent from a user question."""

    if not question or not question.strip():
        raise ValueError("Question cannot be empty.")

    llm = create_llm()
    structured_llm = llm.with_structured_output(ExtractedQueryIntent)

    messages = [
        ("system", SYSTEM_PROMPT),
        ("human", question.strip()),
    ]

    result = structured_llm.invoke(messages)

    if not isinstance(result, ExtractedQueryIntent):
        raise TypeError(
            "LLM returned an unexpected structured-output type."
        )

    return result
# Change End